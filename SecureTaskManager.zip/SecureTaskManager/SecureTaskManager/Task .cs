﻿using System;

namespace SecureTaskManager
{
    public class Task
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsCompleted { get; set; }

        public Task()
        {
            DueDate = DateTime.Today.AddDays(1);
            IsCompleted = false;
        }

        public override string ToString()
        {
            string status = IsCompleted ? "Completed" : "Pending";
            return $"{Title} - Due: {DueDate:MM/dd/yyyy} - {status}";
        }
    }
}
﻿using System;
using System.Windows.Forms;

namespace SecureTaskManager
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            
            using (var loginForm = new LoginForm())
            {
                if (loginForm.ShowDialog() == DialogResult.OK && loginForm.IsAuthenticated)
                {
                    
                    Application.Run(new MainForm());
                }
                else
                {
                    
                    MessageBox.Show("Application closed by user", "Info",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
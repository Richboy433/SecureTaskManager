﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace SecureTaskManager
{
    public partial class MainForm : Form
    {
        private List<TaskItem> tasks;
        private string dataFile = "tasks.json";
        private bool isEditing = false;
        private int editingTaskId = -1;

        public MainForm()
        {
            InitializeComponent();
            InitializeData();
        }

        private void InitializeData()
        {
            try
            {
                
                if (File.Exists(dataFile))
                {
                    string json = File.ReadAllText(dataFile);
                    tasks = JsonConvert.DeserializeObject<List<TaskItem>>(json) ?? new List<TaskItem>();
                }
                else
                {
                    tasks = new List<TaskItem>();
                }

                LoadTasks();
                lblStatus.Text = "Data loaded successfully";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Data Error: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                tasks = new List<TaskItem>();
            }
        }

        private void LoadTasks()
        {
            try
            {
                
                var sortedTasks = tasks.OrderBy(t => t.DueDate).ToList();

                
                DataTable dt = new DataTable();
                dt.Columns.Add("Id", typeof(int));
                dt.Columns.Add("Title", typeof(string));
                dt.Columns.Add("Description", typeof(string));
                dt.Columns.Add("DueDate", typeof(DateTime));
                dt.Columns.Add("IsCompleted", typeof(bool));
                dt.Columns.Add("CreatedAt", typeof(DateTime));

                foreach (var task in sortedTasks)
                {
                    dt.Rows.Add(task.Id, task.Title, task.Description, task.DueDate, task.IsCompleted, task.CreatedAt);
                }

                dataGridViewTasks.DataSource = dt;
                UpdateTaskCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading tasks: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateTaskCount()
        {
            try
            {
                var totalTasks = tasks.Count;
                var completedTasks = tasks.Count(t => t.IsCompleted);
                lblStatus.Text = $"Tasks: {completedTasks}/{totalTasks} completed";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Error updating status";
            }
        }

        private void SaveTasks()
        {
            try
            {
                string json = JsonConvert.SerializeObject(tasks, Formatting.Indented);
                File.WriteAllText(dataFile, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving tasks: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                UpdateTask();
            }
            else
            {
                AddTask();
            }
        }

        private void AddTask()
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Please enter a task title", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var newTask = new TaskItem
                {
                    Id = tasks.Count > 0 ? tasks.Max(t => t.Id) + 1 : 1,
                    Title = txtTitle.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    DueDate = dtpDueDate.Value,
                    IsCompleted = false,
                    CreatedAt = DateTime.Now
                };

                tasks.Add(newTask);
                SaveTasks();
                ClearForm();
                LoadTasks();

                MessageBox.Show("Task added successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding task: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateTask()
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Please enter a task title", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var task = tasks.FirstOrDefault(t => t.Id == editingTaskId);
                if (task != null)
                {
                    task.Title = txtTitle.Text.Trim();
                    task.Description = txtDescription.Text.Trim();
                    task.DueDate = dtpDueDate.Value;

                    SaveTasks();
                    ClearForm();
                    LoadTasks();

                    MessageBox.Show("Task updated successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating task: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridViewTasks.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a task to edit", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var selectedRow = dataGridViewTasks.SelectedRows[0];
                editingTaskId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                var task = tasks.FirstOrDefault(t => t.Id == editingTaskId);
                if (task != null)
                {
                    txtTitle.Text = task.Title;
                    txtDescription.Text = task.Description;
                    dtpDueDate.Value = task.DueDate;

                    isEditing = true;
                    btnCancel.Visible = true;
                    btnAdd.Text = "Update Task";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error selecting task: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewTasks.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a task to delete", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this task?", "Confirm Delete",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    var selectedRow = dataGridViewTasks.SelectedRows[0];
                    int taskId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                    tasks.RemoveAll(t => t.Id == taskId);
                    SaveTasks();
                    LoadTasks();

                    MessageBox.Show("Task deleted successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting task: {ex.Message}", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnMarkComplete_Click(object sender, EventArgs e)
        {
            if (dataGridViewTasks.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a task", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var selectedRow = dataGridViewTasks.SelectedRows[0];
                int taskId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                var task = tasks.FirstOrDefault(t => t.Id == taskId);
                if (task != null)
                {
                    task.IsCompleted = !task.IsCompleted;
                    SaveTasks();
                    LoadTasks();

                    MessageBox.Show($"Task marked as {(task.IsCompleted ? "complete" : "incomplete")}!",
                        "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating task: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Confirm Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void ClearForm()
        {
            txtTitle.Clear();
            txtDescription.Clear();
            dtpDueDate.Value = DateTime.Now.AddDays(1);
            isEditing = false;
            editingTaskId = -1;
            btnCancel.Visible = false;
            btnAdd.Text = "Add Task";
        }

        private void MainForm_Load(object sender, EventArgs e) { }
        private void dataGridViewTasks_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }

    
    public class TaskItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}